package org.example;

public final class Const
{
    private Const() {};


    public static String MAIN_URL_PROP = "main_url";
}
